﻿namespace Client_Octopus
{
    internal class TimerTickEventArgs
    {
    }
}