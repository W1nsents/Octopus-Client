﻿using Client_Octopus.ClientBase.Modules;
using Client_Octopus.ClientBase.Modules.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.UI.VObjs
{
    public class VModuleSliderSetting : VSliderItem
    {
        SliderSetting setting;
        SliderFloatSetting setting2;
        public override int value { 
            get
            {
                return setting.value;
            }
            set
            {
                if(setting!=null)
                    setting.value = value;
            }
        }
        public VModuleSliderSetting(SliderSetting setting) : base(setting.text, setting.min, setting.value, setting.max)
        {
            this.setting = setting;
        }
    }
}
