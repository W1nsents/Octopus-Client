﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Modules;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using Client_Octopus.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Keybinds
{
    public class KeybindHandler
    {
        [DllImport("user32", SetLastError = true)]
        public static extern bool GetAsyncKeyState(char vKey);
        public static bool isKeyDown(char key) { return GetAsyncKeyState(key); }

        public static KeybindHandler handler;
        public static EventHandler<clientKeyEvent> clientKeyDownEvent;
        public static EventHandler<clientKeyEvent> clientKeyHeldEvent;
        public static EventHandler<clientKeyEvent> clientKeyUpEvent;

        Dictionary<char, uint> downBuffs = new Dictionary<char, uint>();
        Dictionary<char, bool> noKey = new Dictionary<char, bool>();

        Dictionary<char, uint> releaseBuffs = new Dictionary<char, uint>();
        Dictionary<char, bool> yesKey = new Dictionary<char, bool>();

        public KeybindHandler()
        {
            handler = this;
            for (char c = (char)0; c < 0xFF; c++)
            {
                downBuffs.Add(c, 0);
                noKey.Add(c, true);
            }
            for (char c = (char)0; c < 0xFF; c++)
            {
                releaseBuffs.Add(c, 0);
                yesKey.Add(c, true);
            }
            OctopusInject.mainLoop += (object sen, EventArgs e)=>
            {
                if (MCM.isMinecraftFocused())
                {
                    for (char c = (char)0; c < 0xFF; c++)
                    {
                        noKey[c] = true;
                        if (GetAsyncKeyState(c))
                        {
                            noKey[c] = false;
                            if (downBuffs[c] > 0)
                            {
                                continue;
                            }
                            downBuffs[c]++;
                            OverlayHost.ui.Invalidate();
                            try
                            {
                                clientKeyDownEvent.Invoke(this, new clientKeyEvent(c));
                            }
                            catch (Exception) { }
                        }
                        if (noKey[c])
                        {
                            downBuffs[c] = 0;
                        }
                    }
                }
            };
            OctopusInject.mainLoop += (object sen, EventArgs e) =>
            {
                if (MCM.isMinecraftFocused())
                {
                    for (char c = (char)0; c < 0xFF; c++)
                    {
                        if (GetAsyncKeyState(c))
                        {
                            try
                            {
                                if(clientKeyHeldEvent != null)
                                {
                                    clientKeyHeldEvent.Invoke(this, new clientKeyEvent(c));
                                }
                            } catch (Exception) { }
                        }
                    }
                }
            };
            OctopusInject.mainLoop += (object sen, EventArgs e) =>
            {
                if (MCM.isMinecraftFocused())
                {
                    for (char c = (char)0; c < 0xFF; c++)
                    {
                        yesKey[c] = false;
                        if (!GetAsyncKeyState(c))
                        {
                            yesKey[c] = true;
                            if (releaseBuffs[c] > 0)
                            {
                                continue;
                            }
                            releaseBuffs[c]++;
                            OverlayHost.ui.Invalidate();
                            if(clientKeyUpEvent != null)
                            {
                                try
                                {
                                    clientKeyUpEvent.Invoke(this, new clientKeyEvent(c));
                                }
                                catch (Exception) { }
                            }
                        }
                        if (!yesKey[c])
                        {
                            releaseBuffs[c] = 0;
                        }
                    }
                }
            };

            clientKeyDownEvent += dispatchKeybinds;
        }

        public void dispatchKeybinds(object sender, clientKeyEvent e)
        {
            foreach(Category cat in CategoryHandler.registry.categories)
            {
                foreach(Module mod in cat.modules)
                {
                    if(mod.keybind == e.key)
                    {
                        mod.enabled = !mod.enabled;
                    }
                }
            }
        }
    }
    public class clientKeyEvent : EventArgs
    {
        public char key;
        public clientKeyEvent(char key)
        {
            this.key = key;
        }
    }
}
