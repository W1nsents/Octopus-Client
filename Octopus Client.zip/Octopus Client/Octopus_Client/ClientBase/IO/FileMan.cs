﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Modules;
using Client_Octopus.ClientBase.Modules.Settings;
using System;
using System.IO;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace Client_Octopus.ClientBase.IO
{
    public class FileMan
    {
        public DirectoryInfo configDir = new DirectoryInfo(Environment.CurrentDirectory+"/OctopusConfig");
        public FileInfo configFile
        {
            get
            {
                return new FileInfo(configDir.FullName + "/config.json");
            }
        }
        public static FileMan man;
        public FileMan()
        {
            man = this;
        }

        public void saveConfig()
        {
            //Console.WriteLine("Saving...");
            RootObject root = new RootObject();
            int z = 0;
            foreach (Category cat in CategoryHandler.registry.categories)
            {
                foreach (Module mod in cat.modules)
                {
                    int y = 0;
                    foreach (SliderSetting slider in mod.sliderSettings)
                    {
                        root.moduleSliderSettings.Add((int)mod.sliderSettings[y].value);
                        y++;
                    }
                    root.moduleKeybinds.Add(mod.keybind);
                    root.enabledModules.Add(mod.enabled);
                    z++;
                }
            }
            foreach (Category cat in CategoryHandler.registry.categories)
            {
                foreach (Module mod in cat.modules)
                {
                    int y = 0;
                    foreach (SliderFloatSetting slider in mod.sliderFloatSettings)
                    {
                        y++;
                    }
                    root.moduleKeybinds.Add(mod.keybind);
                    root.enabledModules.Add(mod.enabled);
                    z++;
                }
            }
            string json = new JavaScriptSerializer().Serialize(root);
            if (!configDir.Exists)
            {
                configDir.Create();
            }
            if (!configFile.Exists)
            {
                configFile.Create();
            }
            File.WriteAllText(configFile.FullName, json);
            //Console.WriteLine("Saved!");
        }

        //returns false if it fails
        public bool readConfig()
        {
            try
            {
                if (!configDir.Exists)
                {
                    configDir.Create();
                    return false;
                }
                if (!configFile.Exists)
                {
                    configFile.Create();
                    return false;
                }
                string json = File.ReadAllText(configFile.FullName);
                RootObject root = new JavaScriptSerializer().Deserialize<RootObject>(json);
                int z = 0;
                int y = 0;
                foreach (Category cat in CategoryHandler.registry.categories)
                {
                    foreach (Module mod in cat.modules)
                    {
                        foreach (SliderSetting slider in mod.sliderSettings)
                        {
                            slider.value = root.moduleSliderSettings[y];
                            y++;
                        }
                        mod.keybind = root.moduleKeybinds[z];
                        mod.enabled = root.enabledModules[z];
                        z++;
                    }
                }
                return true;
            } catch(Exception)
            {
                MessageBox.Show("Ваши данные конфигурации Octopus, вероятно, повреждены. Удалите их. Конфигурация находится здесь: " + configFile.FullName);
                return false;
            }
        }
    }
}
