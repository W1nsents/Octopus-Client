﻿using System.Collections.Generic;
using Console = Colorful.Console;
using System.Drawing;
using System.Threading;

namespace Client_Octopus.ClientBase.IO
{
    public class RootObject
    {
        public List<bool> enabledModules = new List<bool>();
        public List<char> moduleKeybinds = new List<char>();
        public List<int> moduleSliderSettings = new List<int>();
        public List<int> moduleFloatSliderSetting = new List<int>();
        public RootObject()
        {

        }

        public static void information(string prefix, string message)
        {
            Console.Write("[");
            Console.Write(prefix, Color.Violet);
            Console.WriteLine("] " + message);
            Thread.Sleep(500);
        }

    }
}
