﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Settings
{
    public class Setting
    {
        public string text;
        public Setting(string text)
        {
            this.text = text;
        }
    }
}
