﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.UI;
using Client_Octopus.UI.TabUI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class TabGUI : Module
    {
        public TabGUI() : base("TabGUI", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
        }
        //public override void onEnable()
        //{
        //    base.onDisable();
        //    OverlayHost.ui.Paint += drawUI;
        //}

        //private void drawUI(object sender, PaintEventArgs e)
        //{
        //    if (enabled)
        //    {
        //        TabUiHandler.instance.renderTUI(e.Graphics);
        //    }
        //}
    }
}
