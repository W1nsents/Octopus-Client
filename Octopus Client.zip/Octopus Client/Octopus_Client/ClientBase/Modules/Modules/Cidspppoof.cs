﻿using Octopus_Client.ClientBase.Categories;
using System;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Cidspppoof : Module
    {

        Mem m = new Mem();
        public Cidspppoof() : base("ClientIDspoof", CategoryHandler.registry.categories[5], (char)0x07, false)
        {
        }



        public override void onTick()
        {
            base.onTick();
            Random rnd = new Random();
            Mem m = new Mem();
            int value = rnd.Next(1, 900000000);
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+019209F0,0,28,10,40,8,20", "float", $"{value}");
        }
    }
}
