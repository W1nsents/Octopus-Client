﻿using Octopus_Client.ClientBase.Categories;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class UpdateChunks: Module
    {

        Mem m = new Mem();
        public UpdateChunks() : base("UpdateChunks", CategoryHandler.registry.categories[3], (char)0x07, false)
        {

        }


        public override void onTick()
        {
            base.onTick();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+5BA1A8", "bytes", "90 90 90 90 90 90 90 90 90");
            this.enabled = false;
        }

        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+5BA1A8", "bytes", "F3 41 0F 10 89 A4 00 00 00");
        }
    }
}
