﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class PlayerSpeed : Module
    {
        public PlayerSpeed() : base("Speed", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
            RegisterSliderSetting("Speed", 0, 5, 100);
        }

        public override void onDisable()
        {
            base.onDisable();
            MCM.writeFloat(Pointers.playerSpeed(), (float)0.1);
        }

        public override void onTick()
        {
            base.onTick();
            MCM.writeFloat(Pointers.playerSpeed(), (float)sliderSettings[0].value/100);
        }
    }
}
