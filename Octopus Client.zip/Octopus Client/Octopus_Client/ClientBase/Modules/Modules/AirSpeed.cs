﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class AirSpeed : Module
    {
        public AirSpeed() : base("AirSpeed", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
            RegisterSliderSetting("AirSpeed", 0, 5, 50);
        }

        public override void onDisable()
        {
            base.onDisable();
            MCM.writeFloat(Pointers.flySpeed(), (float)0.1);
        }

        public override void onTick()
        {
            base.onTick();
            MCM.writeFloat(Pointers.flySpeed(), (float)sliderSettings[0].value/100);
        }
    }
}
