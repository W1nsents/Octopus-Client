﻿using Octopus_Client.ClientBase.Categories;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class ItemMini : Module
    {
        Mem m = new Mem();
        public ItemMini() : base("ItemMini", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5234", "float", "0.4");
            m.WriteMemory("Minecraft.Windows.exe+11F5C78", "float", "-0.4");
        }


        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5234", "float", "0.2");
            m.WriteMemory("Minecraft.Windows.exe+11F5C78", "float", "-0.2");
        }
    }
}
