﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Octopus_Client.Memory;
using Memory;
using System;
using Octopus.Properties;
using System.IO;
using Octopus.ClientBase.UI.VObjs;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class ReachLegit : Module
    {

        Mem m = new Mem();
        public ReachLegit() : base("ReachSetChange", CategoryHandler.registry.categories[0], (char)0x07, false)
        { 
        }



        public override void onEnable()
        {
            base.onDisable();
            ReachConsoleSet.reachconsoleset();
        }

    }
}

