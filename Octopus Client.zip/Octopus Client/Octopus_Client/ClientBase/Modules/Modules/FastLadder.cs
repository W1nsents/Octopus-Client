﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Keybinds;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class FastLadder : Module
    {
        public FastLadder() : base("FastLadder", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            byte[] ladderUp = { 0xC7, 0x87, 0xB0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3F };
            byte[] ladderDown = { 0xC7, 0x87, 0xB0, 0x00, 0x00, 0x00, 0xCD, 0xCC, 0xCC, 0xBE };
            MCM.writeBaseBytes(Pointers.ladderUp, ladderUp);
            MCM.writeBaseBytes(Pointers.ladderDown, ladderDown);
        }

        public override void onDisable()
        {
            base.onDisable();
            byte[] ladderUp = { 0xC7, 0x87, 0xB0, 0x00, 0x00, 0x00, 0xCD, 0xCC, 0x4C, 0x3E };
            byte[] ladderDown = { 0xC7, 0x87, 0xB0, 0x00, 0x00, 0x00, 0x9A, 0x99, 0x19, 0xBE };
            MCM.writeBaseBytes(Pointers.ladderUp, ladderUp);
            MCM.writeBaseBytes(Pointers.ladderDown, ladderDown);
        }
    }
}
