﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class HeadPlusPlus : Module
    {
        public HeadPlusPlus() : base("HeadPlus", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            byte[] write = { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
            MCM.writeBaseBytes(Pointers.headpluss, write);
        }
        public override void onDisable()
        {
            base.onDisable();
            byte[] write = { 0xC7, 0x81, 0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB4, 0x42 };
            MCM.writeBaseBytes(Pointers.headpluss, write);
        }
    }
}
