﻿using Octopus_Client.ClientBase.Categories;
using System.Threading;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Twerk : Module
    {
        Mem m = new Mem();
        public Twerk() : base("Twerk", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
            RegisterSliderSetting("Delay", 0, 50, 100);
        }


        public override void onTick()
        {
            base.onTick();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+443E54", "bytes", "80 7B 62 01"); // X
            Thread.Sleep(sliderSettings[0].value / 10);
            m.WriteMemory("Minecraft.Windows.exe+443E54", "bytes", "80 7B 62 00"); // X
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+443E54", "bytes", "80 7B 62 00"); // X
        }
    }
}
