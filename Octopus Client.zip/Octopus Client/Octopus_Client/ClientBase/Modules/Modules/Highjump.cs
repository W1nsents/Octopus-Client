﻿using Octopus_Client.ClientBase.Categories;
using Memory;
using Octopus_Client.Memory.CraftSDK;
using Client_Octopus.ClientBase.Keybinds;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class HighJump : Module
    {
        public HighJump() : base("HighJump", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
            KeybindHandler.clientKeyHeldEvent += KeyHeldEvent;
            RegisterSliderSetting("Jump Height", 0, 06, 100);
        }
        Mem m = new Mem();

            public void KeyHeldEvent(object sender, clientKeyEvent e)
            {
                if (e.key == (char)0x20)
                {
                    if (enabled)
                    {
                        if (SDK.instance.player.isInAir > 1 | SDK.instance.player.onGround > 0) SDK.instance.player.velY = (float)sliderSettings[0].value / 10F;
                    }
                }
            }
        



    }
}
