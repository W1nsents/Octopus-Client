﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Keybinds;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Instabreak : Module
    {
        public Instabreak() : base("InstaBreak", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            byte[] write = { 0xC7, 0x46, 0x28, 0x00, 0x00, 0x80, 0x3F };
            MCM.writeBaseBytes(Pointers.blockBreak, write);
        }

        public override void onDisable()
        {
            base.onDisable();
            byte[] write = { 0xF3, 0x0F, 0x11, 0x46, 0x28, 0x80, 0x3F };
            MCM.writeBaseBytes(Pointers.blockBreak, write);
        }
    }
}
