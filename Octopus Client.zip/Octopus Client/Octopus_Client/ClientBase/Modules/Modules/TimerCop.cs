﻿using Octopus_Client.ClientBase.Categories;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class TimerCop : Module
    {

       Mem m = new Mem();
        public TimerCop() : base("Timer", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
            RegisterSliderSetting("Timer", 0, 50, 50000);
        }


        void timerr(float timerR)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5768", "double", timerR.ToString());

        }

        public override void onTick()
        {
            base.onTick();
            timerr((float)sliderSettings[0].value * 1);
        }

        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            if (this.enabled == true) ;
            else { timerr(1000f); this.enabled = false; }
        }
    }
}
