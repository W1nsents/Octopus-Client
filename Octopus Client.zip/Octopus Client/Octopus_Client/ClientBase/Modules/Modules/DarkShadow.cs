﻿using Octopus_Client.ClientBase.Categories;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class DarkShadow : Module
    {
        Mem m = new Mem();
        public DarkShadow() : base("DarkShadow", CategoryHandler.registry.categories[3], (char)0x07, false)
        {

        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+5AE18F", "bytes", "90 90 90 90 90 90 90 90");

        }
        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+5AE18F", "bytes", "F3 0F 10 05 85 71 C4 00");


        }
    }
}
