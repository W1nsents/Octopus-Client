﻿using Octopus_Client.ClientBase.Categories;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class AirJump : Module
    {

        Mem m = new Mem();
        public AirJump() : base("AirJump", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+78FE62", "bytes", "C7 86 2E 01 00 00 01 00 00 00 66 C7 47 16");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+78FE62", "bytes", "0F B6 86 2E 01 00 00 88 47 14 66 C7 47 16");
        }
    }
}
