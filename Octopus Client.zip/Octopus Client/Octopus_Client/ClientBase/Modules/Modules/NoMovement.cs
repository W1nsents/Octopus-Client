﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Octopus_Client.Memory;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Movement: Module
    {

       Mem m = new Mem();
        public Movement() : base("NoHandMovement", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
        }


        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+4AEC02", "bytes", "80 B9 DC 10 00 00 01");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+4AEC02", "bytes", "80 B9 DC 10 00 00 00");
        }
    }
}
