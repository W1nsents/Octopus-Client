﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Jesus : Module
    {

        public static string enemyFlag = "Minecraft.Windows.exe+01921DF8,30,328,0,68,18,8,1C4";
        Mem m = new Mem();
        public Jesus() : base("Jesus", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
            RegisterSliderSetting("Boost", 0, 10, 20);
        }



        public override void onTick()
        {
            base.onTick();
            m.OpenProcess("minecraft.windows");
            {
                int enenmyID = m.ReadInt(enemyFlag);
                if (enenmyID == 65536)
                {
                    SDK.instance.player.velY = (float)sliderSettings[0].value / 10;
                }

            }
        }

    }

}
