﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Fov : Module
    {
        public Fov() : base("Fov", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
            RegisterSliderSetting("fov", 0, 1, 110);
        }

        public override void onDisable()
        {
            base.onDisable();
            MCM.writeFloat(Pointers.fov(), (float)70);
        }

        public override void onTick()
        {
            base.onTick();
            MCM.writeFloat(Pointers.fov(), (float)sliderSettings[0].value * 1);
        }
    }
}
