﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Octopus_Client.Memory;
using Memory;
using System;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Reach : Module
    {

        Mem m = new Mem();
        public Reach() : base("Reach", CategoryHandler.registry.categories[0], (char)0x07, false)
        {
            RegisterSliderSetting("Distance", 0, 3, 7);
        }



        void ReachCall(float reach)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5718", "float", reach.ToString());

        }

        public override void onTick()
        {
            base.onTick();
            ReachCall( (float)sliderSettings[0].value * 1);
        }
        public override void onEnable()
        {
            base.onEnable();
            
        }


        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            if (this.enabled == true) ;
            else { ReachCall(3f); this.enabled = false; }
        }
    }
}
