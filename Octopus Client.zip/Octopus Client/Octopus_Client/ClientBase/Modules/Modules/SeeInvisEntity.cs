﻿using Octopus_Client.ClientBase.Categories;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class SeeInvisEntity : Module
    {

        Mem m = new Mem();
        public SeeInvisEntity() : base("SeeInvisEntity", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
        }
        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+9CBD04", "bytes", "C7 40 10 00 00 00 00");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+9CBD04", "bytes", "0F B6 40 10 C0 E8 05");
        }
    }
}
