﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Octopus_Client.Memory;
using Memory;
using System;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class NoSlowDown : Module
    {

        Mem m = new Mem();
        public NoSlowDown() : base("NoSlowDown", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
        }


        public override void onEnable()
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F51F4", "float", "1");
        }


        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F51F4", "float", "0.349999994");
        }
    }
}
