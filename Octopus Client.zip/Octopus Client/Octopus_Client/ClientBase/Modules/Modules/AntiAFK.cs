﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class AntiAFK : Module
    {
        Mem m = new Mem();
        public AntiAFK() : base("AntiAFK", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+A1F41E", "bytes", "83 BB 30 11 00 00 01");
        }
        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+A1F41E", "bytes", "44 38 B3 30 11 00 00");
        }
    }
}
