﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using Memory;
using System.Threading;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class NoKnockBackLagg : Module
    {
        public NoKnockBackLagg() : base("AntiKnockbackLagg", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
            RegisterSliderSetting("Delay", 0, 100, 1000);
        }
        Mem m = new Mem();

        public override void onTick()
        {
            base.onTick();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+9C7322", "bytes", "90 90 90 90 90 90"); // X
            m.WriteMemory("Minecraft.Windows.exe+9C7334", "bytes", "90 90 90 90 90 90"); // Z
            Thread.Sleep((int)sliderSettings[0].value / 10);
            m.WriteMemory("Minecraft.Windows.exe+9C7322", "bytes", "89 81 AC 00 00 00"); // X
            m.WriteMemory("Minecraft.Windows.exe+9C7334", "bytes", "89 81 B4 00 00 00"); // Z
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+9C7322", "bytes", "89 81 AC 00 00 00"); // X
            m.WriteMemory("Minecraft.Windows.exe+9C7334", "bytes", "89 81 B4 00 00 00"); // Z
        }
    }
}
