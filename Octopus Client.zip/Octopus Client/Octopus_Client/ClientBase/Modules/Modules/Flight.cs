﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Flight : Module
    {
        public Flight() : base("Flight", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
            RegisterSliderSetting("Speed", 0, 0, 100);
        }

        public override void onEnable()
        {
            base.onEnable();
            byte[] write = { 0x80, 0x78, 0x34, 0x01 };
            MCM.writeBaseBytes(Pointers.noclipfly1, write);
        }

        public override void onDisable()
        {
            base.onDisable();
            byte[] write = { 0x80, 0x78, 0x34, 0x00 };
            MCM.writeFloat(Pointers.defflyspeed(), (float)0.05000000075);
            MCM.writeBaseBytes(Pointers.noclipfly1, write);
        }
        public override void onTick()
        {
            base.onTick();
            MCM.writeFloat(Pointers.defflyspeed(), (float)sliderSettings[0].value / 100);
        }
    }
}
