﻿using Octopus_Client.ClientBase.Categories;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class NoCameraCollision : Module
    {

        Mem m = new Mem();
        public NoCameraCollision() : base("NoCollision", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+5BB08B", "bytes", "90 90 90 90 90 90 90 90");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+5BB08B", "bytes", "F3 0F 11 8B A8 12 00 00");
        }
    }
}
