﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Step : Module
    {
        public Step() : base("Step", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
        }

        public override void onDisable()
        {
            base.onDisable();
            MCM.writeFloat(Pointers.stepsizee(), (float)0.5625);
        }

        public override void onTick()
        {
            base.onTick();
            MCM.writeFloat(Pointers.stepsizee(), (float)1.5f);
        }
    }
}
