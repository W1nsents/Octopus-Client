﻿using Octopus_Client.ClientBase.Categories;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class RainbowParticle : Module
    {

        Mem m = new Mem();
        public RainbowParticle() : base("RainbowParticle", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+49C360", "bytes", "90 90 90 90 90 90 90 90");
            m.WriteMemory("Minecraft.Windows.exe+49C368", "bytes", "90 90 90 90 90 90 90 90");
            m.WriteMemory("Minecraft.Windows.exe+49C370", "bytes", "90 90 90 90 90 90 90 90");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+49C360", "bytes", "F3 0F 10 81 94 00 00 00");
            m.WriteMemory("Minecraft.Windows.exe+49C368", "bytes", "F3 0F 10 A9 88 00 00 00");
            m.WriteMemory("Minecraft.Windows.exe+49C370", "bytes", "F3 0F 10 A1 8C 00 00 00");
        }
    }
}
