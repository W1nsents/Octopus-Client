﻿using Octopus_Client.ClientBase.Categories;
using Memory;
using System.Threading;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class HitboxX : Module
    {
        public static string f5Flag = "Minecraft.Windows.exe+019209F0,0,8,8,0,10,28,98";
        public HitboxX() : base("HitBoxLegit", CategoryHandler.registry.categories[0], (char)0x07, false)
        {
        }

        Mem m = new Mem();
        public override void onTick()
        {
            base.onTick();
            m.OpenProcess("Minecraft.Windows");
            int enenmyID = m.ReadInt(f5Flag);
            if (enenmyID == 0)
            {
                m.OpenProcess("Minecraft.Windows");
                m.WriteMemory("Minecraft.Windows.exe+A20B57", "bytes", "C7 87 98 01 00 00 9A 99 99 3F");
                m.WriteMemory("Minecraft.Windows.exe+A20B61", "bytes", "33 CD");
            }
            else
            {
                m.OpenProcess("Minecraft.Windows");
                m.WriteMemory("Minecraft.Windows.exe+A20B57", "bytes", "C7 87 98 01 00 00 9A 99 19 3F");
                m.WriteMemory("Minecraft.Windows.exe+A20B61", "bytes", "33 CD");
                m.WriteMemory("Minecraft.Windows.exe+01921DF8,30,18,0,198", "float", "0.6000000238");
            }
        }
        

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+A20B57", "bytes", "C7 87 98 01 00 00 9A 99 19 3F");
            m.WriteMemory("Minecraft.Windows.exe+A20B61", "bytes", "33 CD");
            m.WriteMemory("Minecraft.Windows.exe+01921DF8,30,18,0,198", "float", "0.6000000238");
        }
    }
}
