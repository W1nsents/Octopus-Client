﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Octopus_Client.Memory;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class HandSoView : Module
    {

        Mem m = new Mem();
        public HandSoView() : base("HandView", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
            RegisterSliderSetting("A", 9, 0, 0);
            RegisterSliderSetting("B", 0, 0, 9);
        }

        void HandA(float handa)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5C78", "float", handa.ToString());
        }

        void HandB(float handb)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5234", "float", handb.ToString());
        }



        public override void onTick()
        {
            base.onTick();
            HandA((float)sliderSettings[0].value / 10);
            base.onTick();
            HandB(sliderSettings[1].value / 10000F);
        }

        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            if (this.enabled == true) ;
            else
            {
                HandA(-0.4f); this.enabled = false;
                HandB(0.4f); this.enabled = false;
            }
                
           
        }
    }
}
