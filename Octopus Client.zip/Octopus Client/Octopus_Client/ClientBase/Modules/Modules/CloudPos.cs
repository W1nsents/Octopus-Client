﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Octopus_Client.Memory;
using Memory;
using System;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class CloudPos : Module
    {

        Mem m = new Mem();
        public CloudPos() : base("CloudPosition", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
            RegisterSliderSetting("Pos", 0, 128, 256);
        }



        void CLS(float clss)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5920", "float", clss.ToString());

        }

        public override void onTick()
        {
            base.onTick();
            CLS((float)sliderSettings[0].value * 1);
        }


        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5920", "float", "128");
        }
    }
}

