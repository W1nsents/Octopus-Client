﻿using Octopus_Client.ClientBase.Categories;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class ItemRock : Module
    {
        Mem m = new Mem();
        public ItemRock() : base("ItemRocking", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F4F58", "float", "1");
        }


        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F4F58", "float", "0.01099999994");
        }
    }
}
