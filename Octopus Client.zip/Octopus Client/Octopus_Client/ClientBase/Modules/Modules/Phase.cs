﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Phase : Module
    {
        public Phase() : base("Phase", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            byte[] write = { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
            MCM.writeBaseBytes(Pointers.stepsize, write);
        }
        public override void onDisable()
        {
            base.onDisable();
            byte[] write = { 0xF2, 0x41, 0x0F, 0x10, 0x46, 0x0C };
            MCM.writeBaseBytes(Pointers.stepsize, write);
        }
    }
}
