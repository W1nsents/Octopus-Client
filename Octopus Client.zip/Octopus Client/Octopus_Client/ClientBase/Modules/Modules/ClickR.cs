﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Keybinds;
using Octopus_Client.Memory.CraftSDK;
using Memory;
using Octopus.Properties;
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Client_Octopus.ClientBase.Modules.Modules
{


    public class ClickR : Module
    {

        Mem m = new Mem();

        //Import

        [DllImport("user32.dll")]
        public static extern void mouse_event(int a, int b, int c, int d, int well);

        int rightDown = 0x08;
        int rightUp = 0x10;



        public ClickR() : base("AutoClicker [Right]", CategoryHandler.registry.categories[0], (char)0x07, false)
        {
            KeybindHandler.clientKeyUpEvent += UpKeyHeld;
            RegisterSliderSetting("Delay", 0, 50, 100);
        }
        public void UpKeyHeld(object sender, clientKeyEvent e)
        {
            if (e.key == keybind)
            {
                enabled = false;
            }
        }
        public override void onTick()
        {
            base.onTick();
            m.OpenProcess("minecraft.windows");
            {
                    m.OpenProcess("minecraft.windows");
                    mouse_event(rightDown, 0, 0, 0, 0);
                    Thread.Sleep(sliderSettings[0].value * 1);
                    mouse_event(rightUp, 0, 0, 0, 0);
                    Thread.Sleep(sliderSettings[0].value * 1);
            }
        }

    }

}
