﻿using Octopus_Client.ClientBase.Categories;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class WithoutSquat : Module
    {
        Mem m = new Mem();  
        public WithoutSquat() : base("WithoutSquat", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+5BA8FD", "bytes", "90 90 90 90 90 90 90 90 90");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+5BA8FD", "bytes", "F3 44 0F 58 25 BA A7 C3 00");
        }
    }
}
