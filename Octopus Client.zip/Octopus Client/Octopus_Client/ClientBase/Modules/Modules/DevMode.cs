﻿using Octopus_Client.ClientBase.Categories;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class DevMode : Module
    {
        Mem m = new Mem();
        public DevMode() : base("DevMode", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+18C9FAA", "byte", "1");
        }
        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+18C9FAA", "byte", "0");
        }
    }
}
