﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Octopus_Client.Memory;
using Memory;
using System.Threading;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class ReachBypass : Module
    {

        Mem m = new Mem();
        public static string enemyFlag = "Minecraft.Windows.exe+01921888,10,60,13C8,10,3C8";
        public ReachBypass() : base("ReachBypass", CategoryHandler.registry.categories[0], (char)0x07, false)
        {
        }



        public override void onTick()
        {
            base.onTick();
            m.OpenProcess("minecraft.windows");
            {
                int enenmyID = m.ReadInt(enemyFlag);
                if (enenmyID == 1)
                {
                    m.OpenProcess("minecraft.windows");
                    m.WriteMemory("Minecraft.Windows.exe+11F5718", "bytes", "00 00 A0 40 DB 0F 49 40");
                }
                else if (enenmyID == 3)
                {
                    m.OpenProcess("minecraft.windows");
                    m.WriteMemory("Minecraft.Windows.exe+11F5718", "bytes", "00 00 40 40 DB 0F 49 40");
                }
                else if (enenmyID == 0)
                {
                m.OpenProcess("minecraft.windows");
                m.WriteMemory("Minecraft.Windows.exe+11F5718", "bytes", "00 00 40 40 DB 0F 49 40");
            }

            }
        }
        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            {
                int enenmyID = m.ReadInt(enemyFlag);
                if (enenmyID == 1)
                {
                    m.OpenProcess("minecraft.windows");
                    m.WriteMemory("Minecraft.Windows.exe+11F5718", "bytes", "00 00 40 40 DB 0F 49 40");

                }

            }
        }

    }

}

