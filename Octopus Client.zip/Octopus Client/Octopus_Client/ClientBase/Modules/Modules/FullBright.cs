﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Octopus_Client.Memory;
using Memory;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class FullBright: Module
    {

       Mem m = new Mem();
        public FullBright() : base("FullBright", CategoryHandler.registry.categories[3], (char)0x07, false)
        {

        }
        //Minecraft.Windows.exe+01921DF8,0,58,18,130 - LocalPlayer

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+019209F0,8,10,0,0,0,10,0,28,98", "float", "100");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("Minecraft.Windows");
            m.WriteMemory("Minecraft.Windows.exe+019209F0,8,10,0,0,0,10,0,28,98", "float", "1");
        }
    }
}
