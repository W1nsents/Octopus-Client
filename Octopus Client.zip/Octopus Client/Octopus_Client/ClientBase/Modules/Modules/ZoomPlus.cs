﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Memory;
using Client_Octopus.ClientBase.Keybinds;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class ZoomPlus : Module
    {

        Mem m = new Mem();
        public ZoomPlus() : base("ZoomPlus", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
            RegisterSliderSetting("Distance", 0, 1, 130);
            KeybindHandler.clientKeyUpEvent += UpKeyHeld;
        }

        public void UpKeyHeld(object sender, clientKeyEvent e)
        {
            if (e.key == keybind)
            {
                enabled = false;
            }
        }


        void Zooms(float zommp)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5928", "float", zommp.ToString());
        }

        public override void onTick()
        {
            base.onTick();
            Zooms( (float)sliderSettings[0].value * 1);
        }

        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            if (this.enabled == true) ;
            else { Zooms(130f); this.enabled = false; }
        }
    }
}
