﻿using Octopus_Client.ClientBase.Categories;
using Memory;
using System.Threading;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class BodyHeadStop : Module
    {
        Mem m = new Mem();
        public BodyHeadStop() : base("HeadSpinner", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
            RegisterSliderSetting("Delay", 0, 35, 100);
        }

        public override void onTick()
        {
            base.onTick();
                m.OpenProcess("minecraft.windows");
                m.WriteMemory("Minecraft.Windows.exe+4A8EBA", "bytes", "90 90 90 90 90 90 90 90");
                Thread.Sleep((int)sliderSettings[0].value * 1);
                m.WriteMemory("Minecraft.Windows.exe+4A8EBA", "bytes", "F2 0F 10 87 B8 00 00 00");
            
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+4A8EBA", "bytes", "F2 0F 10 87 B8 00 00 00");
        }
    }
}
