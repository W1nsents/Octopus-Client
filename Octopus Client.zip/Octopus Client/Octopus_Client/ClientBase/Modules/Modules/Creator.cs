﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Memory;
using System.Diagnostics;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Creator : Module
    {

        Mem m = new Mem();
        public Creator() : base("Creator", CategoryHandler.registry.categories[5], (char)0x07, false)
        {
        }



        public override void onEnable()
        {
            base.onDisable();
            Process.Start("https://vk.com/podsq");
        }
    }
}
