﻿using Octopus_Client.ClientBase.Categories;
using Memory;
using System.Runtime.InteropServices;
using System.Threading;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class AutoConstruction : Module
    {

        [DllImport("user32.dll")]
        public static extern void mouse_event(int a, int b, int c, int d, int well);

        int rightDown = 0x08;
        int rightUp = 0x10;


        //Pointers
        public static string constFlag = "Minecraft.Windows.exe+01921DF8,18,38,58,28,308,30,40C";
        public static string screenTflag = "Minecraft.Windows.exe+1921DF8,8,340,20,368,8,28,BB0";
        Mem m = new Mem();
        public AutoConstruction() : base("AutoConstruction", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
            RegisterSliderSetting("Delay", 0, 35, 100);
        }

        public override void onTick()
        {
            base.onTick();

            m.OpenProcess("minecraft.windows");
            int screenID = m.ReadInt(screenTflag);
            if (screenID == 0)
            {
                int enenmyID = m.ReadInt(constFlag);
                if (enenmyID == 1)
                {
                    m.OpenProcess("minecraft.windows");
                    mouse_event(rightDown, 0, 0, 0, 0);
                    Thread.Sleep(sliderSettings[0].value / 10);
                    mouse_event(rightUp, 0, 0, 0, 0);
                    Thread.Sleep(sliderSettings[0].value / 10);
                }
            }
        }
    }
}
