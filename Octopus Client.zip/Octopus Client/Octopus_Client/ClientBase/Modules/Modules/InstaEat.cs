﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Keybinds;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Instaeat : Module
    {
        public Instaeat() : base("InstaEat", CategoryHandler.registry.categories[2], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            byte[] write = { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
            MCM.writeBaseBytes(Pointers.InstantEat, write);
        }

        public override void onDisable()
        {
            base.onDisable();
            byte[] write = { 0x8B, 0x86, 0xC0, 0x14, 0x00, 0x00 };
            MCM.writeBaseBytes(Pointers.InstantEat, write);
        }
    }
}
