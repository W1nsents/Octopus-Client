﻿using Octopus_Client.ClientBase.Categories;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class NoHurtCam : Module
    {

        Mem m = new Mem();
        public NoHurtCam() : base("NoHurtCam", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+5B6A05", "bytes", "90 90 90 90 90 90 90 90 90");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+5B6A05", "bytes", "66 44 0F 6E 83 6C 0E 00 00");
        }
    }
}
