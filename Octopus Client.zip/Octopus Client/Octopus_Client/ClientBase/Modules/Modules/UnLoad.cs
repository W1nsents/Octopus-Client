﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using Memory;
using System.Diagnostics;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class UnLoad : Module
    {

        Mem m = new Mem();
        public UnLoad() : base("Unhook", CategoryHandler.registry.categories[5], (char)0x07, false)
        {
        }


        void fovv(float fovvv)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5870", "float", fovvv.ToString());

        }

        void ReachCall(float reach)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5718", "float", reach.ToString());

        }

        void timerr(float timerR)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5768", "double", timerR.ToString());
        }
        void Zooms(float zommp)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5928", "float", zommp.ToString());
        }


        public override void onEnable()
        {
            m.OpenProcess("minecraft.windows");
            base.onDisable();
            MCM.writeFloat(Pointers.weather(), (float)0F); //Weather
            MCM.writeFloat(Pointers.stepsizee(), (float)0.5625); //Step
            MCM.writeFloat(Pointers.flySpeed(), (float)0.1); //AirSpeed
            byte[] write1 = { 0x0F, 0xB6, 0x41, 0x63 }; // AutoSprint
            MCM.writeBaseBytes(Pointers.autoSprint, write1); // AutoSprint
            byte[] ladderUp = { 0xC7, 0x87, 0xB0, 0x00, 0x00, 0x00, 0xCD, 0xCC, 0x4C, 0x3E }; // FastLadder
            byte[] ladderDown = { 0xC7, 0x87, 0xB0, 0x00, 0x00, 0x00, 0x9A, 0x99, 0x19, 0xBE }; // FastLadder
            MCM.writeBaseBytes(Pointers.ladderUp, ladderUp); // FastLadder
            MCM.writeBaseBytes(Pointers.ladderDown, ladderDown); // FastLadder
            byte[] write2 = { 0x80, 0x78, 0x34, 0x00 }; // Flight
            MCM.writeBaseBytes(Pointers.noclipfly1, write2); // Flight
            MCM.writeFloat(Pointers.fov(), (float)70); // Fov
            if (this.enabled == true) ; // Fov Plus
            else { fovv(30f); this.enabled = false; } // Fov Plus
            MCM.writeFloat(Pointers.handma(), (float)1); // HandSoView
            byte[] write3 = { 0xC7, 0x81, 0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB4, 0x42 }; // HeadPlusPlus
            MCM.writeBaseBytes(Pointers.headpluss, write3); // HeadPlusPlus
            MCM.writeFloat(Pointers.hitboxwinsent1(), (float)0.6); //HitBox Winsent
            MCM.writeFloat(Pointers.hitboxwinsent2(), (float)0.6); //HitBox Winsent
            MCM.writeFloat(Pointers.hitboxwinsent4(), (float)0.6); //HitBox Winsent
            byte[] write4 = { 0xF3, 0x0F, 0x11, 0x46, 0x28, 0x80, 0x3F }; // InstantBreak
            MCM.writeBaseBytes(Pointers.blockBreak, write4); // InstantBreak
            byte[] write5 = { 0x8B, 0x86, 0xC0, 0x14, 0x00, 0x00 }; //InstantEat
            MCM.writeBaseBytes(Pointers.InstantEat, write5); //InstantEat
            byte[] write6 = { 0x80, 0x78, 0x34, 0x00 }; // NoClip
            byte[] write7 = { 0x0F, 0x2E, 0xCD }; // NoClip
            MCM.writeBaseBytes(Pointers.noclipfly1, write6); // NoClip
            MCM.writeBaseBytes(Pointers.noclip2, write7); // NoClip
            byte[] write8 = { 0x89, 0x81, 0xAC, 0x00, 0x00, 0x00 }; // NoKnockBack
            byte[] write9 = { 0x89, 0x81, 0xB0, 0x00, 0x00, 0x00 }; // NoKnockBack
            byte[] write10 = { 0x89, 0x81, 0xB4, 0x00, 0x00, 0x00 }; // NoKnockBack
            MCM.writeBaseBytes(Pointers.NoKnockBackX, write8); // NoKnockBack
            MCM.writeBaseBytes(Pointers.NoKnockBackY, write9); // NoKnockBack
            MCM.writeBaseBytes(Pointers.NoKnockBackZ, write10); // NoKnockBack
            byte[] write11 = { 0xF3, 0x0F, 0x59, 0x1D, 0xD3, 0x0D, 0xDB, 0x00 }; // NoSlowSneak
            byte[] writenoslowsneak1 = { 0xF3, 0x0F, 0x59, 0x15, 0xDB, 0x0D, 0xDB, 0x00 }; // NoSlowSneak
            MCM.writeBaseBytes(Pointers.NoSlowSneak1, writenoslowsneak1); // NoSlowSneak
            MCM.writeBaseBytes(Pointers.NoSlowSneak2, write11); // NoSlowSneak
            byte[] offs = { 0xC6, 0x83, 0xC6, 0x01, 0x00, 0x00, 0x01 }; // NoWater
            MCM.writeBaseBytes(Pointers.inWaterTick, offs); // NoWater
            byte[] write12 = { 0xF2, 0x41, 0x0F, 0x10, 0x46, 0x0C }; // Phase
            MCM.writeBaseBytes(Pointers.stepsize, write12); // Phase
            MCM.writeFloat(Pointers.playerSpeed(), (float)0.1); // SpeedHack
            if (this.enabled == true) ; // Reach
            else { ReachCall(3f); this.enabled = false; } // Reach
            byte[] write13 = { 0x8B, 0x40, 0x10 }; // Spider
            MCM.writeBaseBytes(Pointers.spider, write13); // Spider
            MCM.writeFloat(Pointers.stepsizee(), (float)0.5625); // Step
            MCM.writeFloat(Pointers.time(), (byte)100); // Time
            if (this.enabled == true) ; // Timer
            else { timerr(1000f); this.enabled = false; } // Timer
            if (this.enabled == true) ; // ZoomPlus
            else { Zooms(130f); this.enabled = false; } // ZoomPlus
            MCM.writeFloat(Pointers.defflyspeed(), (float)0.05000000075); // FlySpeed [X,Z]
            m.WriteMemory("Minecraft.Windows.exe+3545E6", "bytes", "88 86 CC 03 00 00"); // JumpBridge
            m.WriteMemory("Minecraft.Windows.exe+4A8EBA", "bytes", "F2 0F 10 87 B8 00 00 00"); // Body&Head Stop
            m.WriteMemory("Minecraft.Windows.exe+5B68AB", "bytes", "F3 0F 10 89 94 00 00 00"); // Zoom
            m.WriteMemory("Minecraft.Windows.exe+78FE62", "bytes", "0F B6 86 2E 01 00 00 88 47 14 66 C7 47 16"); // AirJump
            m.WriteMemory("Minecraft.Windows.exe+5B67B3", "bytes", "F3 0F 5E BB 28 04 00 00"); // FogOff
            m.WriteMemory("Minecraft.Windows.exe+5B6A05", "bytes", "66 44 0F 6E 83 6C 0E 00 00"); // NoHurtCam
            m.WriteMemory("Minecraft.Windows.exe+9C11E0", "bytes", "C6 81 C4 01 00 00 01"); // NoWeb
            m.WriteMemory("Minecraft.Windows.exe+4A12E3", "bytes", "E8 68 4F CF FF"); // NoPaticle
            m.WriteMemory("Minecraft.Windows.exe+9CBD04", "bytes", "0F B6 40 10 C0 E8 05"); // See Invis Entity
            m.WriteMemory("Minecraft.Windows.exe+5B68AB", "bytes", "F3 0F 10 89 94 00 00 00"); // Zoom
            m.WriteMemory("Minecraft.Windows.exe+5BA8FD", "bytes", "F3 44 0F 58 25 BA A7 C3 00"); // Without Squat
            m.WriteMemory("Minecraft.Windows.exe+49C360", "bytes", "F3 0F 10 81 94 00 00 00"); // RainbowParticle
            m.WriteMemory("Minecraft.Windows.exe+49C368", "bytes", "F3 0F 10 A9 88 00 00 00"); // RainbowParticle
            m.WriteMemory("Minecraft.Windows.exe+49C370", "bytes", "F3 0F 10 A1 8C 00 00 00"); // RainbowParticle
            m.WriteMemory("Minecraft.Windows.exe+5BB08B", "bytes", "F3 0F 11 8B A8 12 00 00"); // NoCameraCollision
            m.WriteMemory("Minecraft.Windows.exe+443E54", "bytes", "80 7B 62 00"); // Sneak Fly
            m.WriteMemory("Minecraft.Windows.exe+4AEC02", "bytes", "80 B9 DC 10 00 00 00"); // NoHandMovement
            m.WriteMemory("Minecraft.Windows.exe+11F51F4", "float", "0.349999994"); // NoSlowDown
            m.WriteMemory("Minecraft.Windows.exe+11F4F90", "float", "0.01999999955"); // Fast Cloud
            m.WriteMemory("Minecraft.Windows.exe+01921DF8,30,18,18,D8,38,10,30", "float", "0"); // Weather
            m.WriteMemory("Minecraft.Windows.exe+11F5920", "float", "128"); // Cloud Pos
            m.WriteMemory("Minecraft.Windows.exe+11F5234", "float", "0.4"); // Mini Item
            m.WriteMemory("Minecraft.Windows.exe+11F5C78", "float", "-0.4"); // Mini Item
            m.WriteMemory("Minecraft.Windows.exe+A1F41E", "bytes", "44 38 B3 30 11 00 00"); // Anti AFk
            m.WriteMemory("Minecraft.Windows.exe+A43800", "bytes", "8B 08 00 00 00 00 FF C9"); // No Reload Item
            m.WriteMemory("Minecraft.Windows.exe+5B68AB", "bytes", "83 BB C8 03 00 00 00"); // Fake Hit
            foreach (Process proc in Process.GetProcessesByName("Octopus"))
            {
                proc.Kill();
            }



            this.enabled = false;
        }
    }
}
