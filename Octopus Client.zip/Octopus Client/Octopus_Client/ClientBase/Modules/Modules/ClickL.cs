﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Keybinds;
using Octopus_Client.Memory.CraftSDK;
using Memory;
using Octopus.Properties;
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Client_Octopus.ClientBase.Modules.Modules
{


    public class ClickL : Module
    {

        Mem m = new Mem();

        //Import

        [DllImport("user32.dll")]
        public static extern void mouse_event(int a, int b, int c, int d, int well);

        int leftDown = 0x02;
        int leftUp = 0x04;



        public ClickL() : base("AutoClicker [Left]", CategoryHandler.registry.categories[0], (char)0x07, false)
        {
            KeybindHandler.clientKeyUpEvent += UpKeyHeld;
            RegisterSliderSetting("Delay", 0, 50, 100);
        }
        public void UpKeyHeld(object sender, clientKeyEvent e)
        {
            if (e.key == keybind)
            {
                enabled = false;
            }
        }
        public override void onTick()
        {
            base.onTick();
            m.OpenProcess("minecraft.windows");
            {
                    m.OpenProcess("minecraft.windows");
                    mouse_event(leftDown, 0, 0, 0, 0);
                    Thread.Sleep((int)sliderSettings[0].value * 1);
                    mouse_event(leftUp, 0, 0, 0, 0);
                    Thread.Sleep((int)sliderSettings[0].value * 1);
            }
        }

    }

}
