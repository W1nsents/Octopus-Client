﻿using Octopus_Client.ClientBase.Categories;
using Memory; 

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class NoReloadItem : Module
    {
        Mem m = new Mem();
        public NoReloadItem() : base("NoReloadItem", CategoryHandler.registry.categories[2], (char)0x07, false)
        {

        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+A43800", "bytes", "C7 00 00 00 00 00 FF C9");
        }
        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+A43800", "bytes", "8B 08 00 00 00 00 FF C9");
        }
    }
}
