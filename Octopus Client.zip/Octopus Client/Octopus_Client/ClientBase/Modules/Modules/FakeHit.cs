﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Memory;
using System.IO.Compression;
using System.IO;
using System.Media;
using Client_Octopus.ClientBase.Keybinds;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class FakeHit : Module
    {

        Mem m = new Mem();
        public FakeHit() : base("FakeHit", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
        }



        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+117AEC", "bytes", "90 90 90 90 90 90 90");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+117AEC", "bytes", "83 BB C8 03 00 00 00");
        }
    }
}
