﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Keybinds;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Criticals : Module
    {
        public Criticals() : base("Criticals [No Work]", CategoryHandler.registry.categories[0], (char)0x07, false)
        {
            KeybindHandler.clientKeyHeldEvent += keyHeldEvent;
        }

        public void keyHeldEvent(object sender, clientKeyEvent e)
        {
            if (enabled)
            {
                {
                    SDK.instance.player.velY = 0.2F;
                }
            }
        }
    }
}
