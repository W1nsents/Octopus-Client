﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Memory;
using System.Diagnostics;
using System.IO;
using Octopus.Properties;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class WhResource : Module
    {

        Mem m = new Mem();
        public static String file_exe = Environment.GetFolderPath(Environment.SpecialFolder.InternetCache) + "\\octopus.mcpack";
        public WhResource() : base("WallHack", CategoryHandler.registry.categories[5], (char)0x07, false)
        {
        }



        public override void onEnable()
        {
            base.onDisable();
            FileStream fs = new FileStream(file_exe, FileMode.Create);
            fs.Write(Resources.octopus, 0, Resources.octopus.Length);
            fs.Close();
            System.Diagnostics.Process.Start(file_exe);

        }
    }
}
