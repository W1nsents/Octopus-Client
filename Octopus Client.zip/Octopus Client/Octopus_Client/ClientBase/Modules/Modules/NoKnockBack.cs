﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Keybinds;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class NoKnockBack : Module
    {
        public NoKnockBack() : base("AntiKnockback", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            byte[] write1 = { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
            byte[] write2 = { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
            byte[] write3 = { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };
            MCM.writeBaseBytes(Pointers.NoKnockBackX, write1);
            MCM.writeBaseBytes(Pointers.NoKnockBackY, write2);
            MCM.writeBaseBytes(Pointers.NoKnockBackZ, write3);


        }

        public override void onDisable()
        {
            base.onDisable();
            byte[] write1 = { 0x89, 0x81, 0xAC, 0x00, 0x00, 0x00 };
            byte[] write2 = { 0x89, 0x81, 0xB0, 0x00, 0x00, 0x00 };
            byte[] write3 = { 0x89, 0x81, 0xB4, 0x00, 0x00, 0x00 };
            MCM.writeBaseBytes(Pointers.NoKnockBackX, write1);
            MCM.writeBaseBytes(Pointers.NoKnockBackY, write2);
            MCM.writeBaseBytes(Pointers.NoKnockBackZ, write3);
        }
    }
}
