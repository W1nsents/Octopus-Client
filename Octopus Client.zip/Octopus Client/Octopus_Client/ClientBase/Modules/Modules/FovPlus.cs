﻿using Octopus_Client.ClientBase.Categories;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class FovPlus : Module
    {
        Mem m = new Mem();
        public FovPlus() : base("FovPlus", CategoryHandler.registry.categories[3], (char)0x07, false)
        {
            RegisterSliderSetting("fov", 0, 1, 130);
        }



        void fovv(float fovvv)
        {
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+11F5870", "float", fovvv.ToString());

        }

        public override void onTick()
        {
            base.onTick();
            fovv((float)sliderSettings[0].value * 1);
        }

        public override void onDisable()
        {
            m.OpenProcess("minecraft.windows");
            if (this.enabled == true) ;
            else { fovv(30f); this.enabled = false; }
        }
    }
}
