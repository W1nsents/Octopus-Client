﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Keybinds;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class Glide : Module
    {
        public Glide() : base("Glide", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
            RegisterSliderSetting("Value", -10, 0, 10);
        }

        public override void onTick()
        {
            base.onTick();
            MCM.writeFloat(Pointers.yvel(), sliderSettings[0].value * 0);
        }
    }
}
