﻿using Octopus_Client.ClientBase.Categories;
using Octopus_Client.Memory.CraftSDK;
using Memory;
using Octopus.Properties;
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Client_Octopus.ClientBase.Modules.Modules
{


    public class Triggerbot : Module
    {

        Mem m = new Mem();

        //Import

        [DllImport("user32.dll")]
        public static extern void mouse_event(int a, int b, int c, int d, int well);

        int leftDown = 0x02;
        int leftUp = 0x04;


        //Pointers
        public static string enemyFlag = "Minecraft.Windows.exe+01921888,10,60,13C8,10,3C8";
        public static string screenTflag = "Minecraft.Windows.exe+1921DF8,8,340,20,368,8,28,BB0";


        public Triggerbot() : base("Triggerbot", CategoryHandler.registry.categories[0], (char)0x07, false)
        {
            RegisterSliderSetting("Delay", 0, 50, 100);
        }

        public override void onTick()
        {
            base.onTick();

            m.OpenProcess("minecraft.windows");
            
                int screenID = m.ReadInt(screenTflag);
                if (screenID == 0)
                {
                    int enenmyID = m.ReadInt(enemyFlag);
                    if (enenmyID == 1)
                    {
                        m.OpenProcess("minecraft.windows");
                        mouse_event(leftDown, 0, 0, 0, 0);
                        Thread.Sleep(sliderSettings[0].value / 10);
                        mouse_event(leftUp, 0, 0, 0, 0);
                        Thread.Sleep(sliderSettings[0].value / 10);

                    }
                }
            
            


        }
    }

}


