﻿using Octopus_Client.ClientBase.Categories;
using Memory;
namespace Client_Octopus.ClientBase.Modules.Modules
{
    public class NoWeb : Module
    {
        Mem m = new Mem();
        public NoWeb() : base("NoWeb", CategoryHandler.registry.categories[1], (char)0x07, false)
        {
        }

        public override void onEnable()
        {
            base.onEnable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+9C11E0", "bytes", "C6 81 C4 01 00 00 00");
        }

        public override void onDisable()
        {
            base.onDisable();
            m.OpenProcess("minecraft.windows");
            m.WriteMemory("Minecraft.Windows.exe+9C11E0", "bytes", "C6 81 C4 01 00 00 01");
        }
    }
}
