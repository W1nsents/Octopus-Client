﻿//using Octopus.ClientBase.Modules;
//using Octopus_Client.ClientBase.Categories;
//using System;
//using System.Collections.Generic;
//using Memory;

//namespace Client_Octopus.ClientBase.Modules.Modules
//{
//    public class Aimbot : Module
//    {
//        public Aimbot() : base("Aimbot", CategoryHandler.registry.categories[0], (char)0x07, false)
//        {
//            RegisterSliderSetting("Range", 0, 120, 500);
//        }
//        Mem m = new Mem();
//        sdk sdk = new sdk();
//        public override void onTick()
//        {
//            base.onTick();
//            List<string> dxentitylist = sdk.getentitylist("4D8");
//            List<string> dyentitylist = sdk.getentitylist("4D0");
//            List<string> dzentitylist = sdk.getentitylist("4D4");


//            float dxself = m.ReadFloat(sdk.LocalPlayer("4D8"));
//            float dyself = m.ReadFloat(sdk.LocalPlayer("4D0"));
//            float dzself = m.ReadFloat(sdk.LocalPlayer("4D4"));


//            float dxentity = m.ReadFloat(dxentitylist[sdk.GetNearestEntity()]);
//            float dyentity = m.ReadFloat(dyentitylist[sdk.GetNearestEntity()]);
//            float dzentity = m.ReadFloat(dzentitylist[sdk.GetNearestEntity()]);



//            float dx = dxself - dxentity;  // Z
//            float dy = dyself - dyentity;  // X
//            float dz = dzself - dzentity; // Y

//            double angleYaw = Math.Atan2(dy, dx) * 3.14 / Math.PI;
//            double distance = Math.Sqrt(dx * dx + dy * dy);
//            double anglePitch = Math.Atan2(dz, distance) * -3.14 / Math.PI;

//            m.WriteMemory(sdk.ViewMatrix("x"), "float", angleYaw.ToString());
//            m.WriteMemory(sdk.ViewMatrix("y"), "float", anglePitch.ToString());


//            float dxself = m.ReadFloat(sdk.LocalPlayer("4D8"));
//            float dyself = m.ReadFloat(sdk.LocalPlayer("4D0"));
//            float dzself = m.ReadFloat(sdk.LocalPlayer("4D4"));


//            float dxentity = m.ReadFloat(dxentitylist[1]);
//            float dyentity = m.ReadFloat(dyentitylist[1]);
//            float dzentity = m.ReadFloat(dzentitylist[1]);



//            float dx = dxself - dxentity;  // Z
//            float dy = dyself - dyentity;  // X
//            float dz = dzself - dzentity; // Y

//            double angleYaw = Math.Atan2(dy, dx) * 3.14 / Math.PI;
//            double distance = Math.Sqrt(dx * dx + dy * dy);
//            double anglePitch = Math.Atan2(dz, distance) * -3.14 / Math.PI;

//            m.WriteMemory(sdk.ViewMatrix("x"), "float", angleYaw.ToString());
//            m.WriteMemory(sdk.ViewMatrix("y"), "float", anglePitch.ToString());
//        }
//    }
//}
