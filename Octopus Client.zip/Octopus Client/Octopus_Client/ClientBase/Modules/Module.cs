﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.IO;
using Client_Octopus.ClientBase.Modules.Settings;
using Octopus_Client.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Octopus.ClientBase.Modules
{
    public abstract class Module
    {
        public string name;
        public bool enabled;
        public bool selected;
        public char keybind;

        private bool wasEnabled = false;
        public EventHandler toggleEvent;

        public Module(string name, Category category, char keybind, bool enabled)
        {
            this.name = name;
            this.keybind = keybind;
            this.enabled = enabled;
            category.modules.Add(this);
        }

        protected Module(string name, Category category, int keybind1, bool enabled)
        {
            this.name = name;
            this.category = category;
            this.keybind1 = keybind1;
            this.enabled = enabled;
        }

        public List<SliderFloatSetting> sliderFloatSettings = new List<SliderFloatSetting>();
        public List<SliderSetting> sliderSettings = new List<SliderSetting>();
        public void RegisterSliderSetting(string text, int min, int value, int max)
        {
            sliderSettings.Add(new SliderSetting(text, min, value, max));
        }
        public void RegisterFloatSliderSetting(string text, float min, float value, float max)
        {
            sliderFloatSettings.Add(new SliderFloatSetting(text, min, value, max));
        }
        public List<ToggleSetting> toggleSettings = new List<ToggleSetting>();
        private Category category;
        private int keybind1;

        public void RegisterToggleSetting(string text, bool value)
        {
            toggleSettings.Add(new ToggleSetting(text, value));
        }

        public virtual void onEnable()
        {
            this.enabled = true;
            FileMan.man.saveConfig();
        }
        public virtual void onDisable()
        {
            this.enabled = false;
            FileMan.man.saveConfig();
        }
        //Called like a loop when enabled
        public virtual void onTick()
        {
            
        }
        //Called no matter what

        public virtual void onLoop()
        {
            if (wasEnabled != enabled)
            {
                if (enabled == false)
                {
                    onDisable();
                    try
                    {
                        if (toggleEvent != null)
                            toggleEvent.Invoke(this, new EventArgs());
                    }
                    catch (Exception) { }
                }
                else
                {
                    onEnable();
                    try
                    {
                        if (toggleEvent != null)
                            toggleEvent.Invoke(this, new EventArgs());

                    }
                    catch (Exception) { }
                }
                wasEnabled = enabled;
            }
            if (enabled)
            {
                onTick();
            }
        }
    }
}
