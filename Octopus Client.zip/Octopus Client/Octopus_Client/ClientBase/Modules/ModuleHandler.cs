﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.Modules.Modules;
using Octopus_Client.Memory.CraftSDK;
using System;
using Client_Octopus.ClientBase.IO;
using System.Media;

namespace Client_Octopus.ClientBase.Modules
{
    public class ModuleHandler
    {
        public static ModuleHandler registry;
        public ModuleHandler()
        {
            registry = this;
            RootObject.information("Информация", "Регистрация модулей!");
            //Combat
            //new Aimbot();
            //new BoostHit();
            new ClickL();
            new ClickR();
            //new Criticals();
            //new Hitbox();
            new HitboxX();
            new Reach();
            //new ReachBypass();
            new ReachLegit();
            new Triggerbot();
            //Movement
            new AirJump();
            new AirStrafe();
            new AirSpeed();
            new AutoSprint();
            new BHOP();
            new FastLadder();
            new Glide();
            new HighJump();
            new Jesus();
            //new Jetpack();
            new NoKnockBack();
            new NoKnockBackLagg();
            new NoSlowDown();
            new NoSlowSneak();
            new NoWater();
            new NoWeb();
            new PlayerSpeed();
            new Step();
            //new Velocity();
            new WithoutSquat();
            //Player
            new AntiAFK();
            new BodyHeadStop();
            new BounceFly();
            new NoReloadItem();
            new Flight();
            new HeadPlusPlus();
            new Phase();
            new NoClip();
            new Spider();
            new Instaeat();
            new Instabreak();
            new InstabreakBypss();
            new ItemMini();
            new ItemRock();
            new Twerk();
            //Misc
            new ClickUI();
            new CloudPos();
            new DevMode();
            new FogOff();
            new FakeHit();
            new Fov();
            new FovPlus();
            new DarkShadow();
            new FullBright();
            //new HandSoView();
            new SeeInvisEntity();
            new JumpBridge();
            new AutoConstruction();
            new ModuleList();
            new Movement();
            new NoCameraCollision();
            new NoHurtCam();
            new PaticleOff();
            new RainbowParticle();
            //new TabGUI();
            new TimerCop();
            new UpdateChunks();
            new Weather();
            new Zoom();
            new ZoomPlus();
            //Minecraft
            new Lobby();
            new Hub();
            new Spawn();
            new TPA();
            //Other
            new Cidspppoof();
            new UnLoad();
            new Creator();
            new WhResource();
            RootObject.information("Информация", "Регистрация модулей завершена!");
            startModuleThread();
        }

        public void startModuleThread()
        {
            OctopusInject.mainLoop += (object sen, EventArgs e) =>
            {
                foreach (Category category in CategoryHandler.registry.categories)
                {
                    foreach (Module module in category.modules)
                    {
                        module.onLoop();
                    }
                }
                new SDK();
            };
        }
    }
}
