﻿using Client_Octopus.ClientBase.IO;
using System;
using System.Drawing;
using Console = Colorful.Console;
using Memory;

namespace Octopus.ClientBase.UI.VObjs
{

    class TerminalDefault
    {
        public static void terminal()
        {
         
                Console.Clear();
                Console.Title = "Терминал | Octopus Cient";
                Console.WriteLine("╔═╦═╦══╦═╦═╦╗╔╦══╗╔═╦╗╔╦═╦═╦╦══╗\n║║║╠╬╗╔╣║║╔╣╚╝╠╗╚╣║╠╣╚╣║╦╣║║╠╗╔╝\n╚═╩═╝╚╝╚═╩╝╚══╩══╝╚═╩═╩╩═╩╩═╝╚╝", Color.Violet);
                RootObject.information("Информация", "Made by Winsent");
                Mem m = new Mem();
          
        }

    }
}
