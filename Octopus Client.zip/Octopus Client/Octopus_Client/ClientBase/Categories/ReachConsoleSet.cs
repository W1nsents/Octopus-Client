﻿using Client_Octopus.ClientBase.IO;
using Memory;
using Octopus_Client.Memory;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Octopus.ClientBase.UI.VObjs
{
    class Hooking
    {
        private string ReachAddr = "Minecraft.Windows.exe+11F5718";
        public void write_reach(Mem m, string value)
        {
            m.WriteMemory(ReachAddr, "float", value);
        }
    }

    class ReachConsoleSet
    {


        public static void reachconsoleset()
        {
            Console.Clear();
            Console.Title = "Терминал | Octopus Cient";
            Console.WriteLine("╔═╦═╦══╦═╦═╦╗╔╦══╗╔═╦╗╔╦═╦═╦╦══╗\n║║║╠╬╗╔╣║║╔╣╚╝╠╗╚╣║╠╣╚╣║╦╣║║╠╗╔╝\n╚═╩═╝╚╝╚═╩╝╚══╩══╝╚═╩═╩╩═╩╩═╝╚╝", Color.Violet);
            RootObject.information("Информация", "Made by Winsent");
            Mem m = new Mem();
            int PID = m.GetProcIdFromName("Minecraft.Windows.exe");
            if (PID > 0)
            {
                m.OpenProcess(PID);
                Run(m);
            }
            else
            {
                TerminalDefault.terminal();
            }
        }
        static void Run(Mem m)
        {
            Hooking hook = new Hooking();
            try 
            {
                Console.Write("Reach -> ");
                string input = Console.ReadLine();
                string value = input.Substring(0);
                hook.write_reach(m, value);
                RootObject.information("Информация", $"Вы изменили значение на {value}!");
                Thread.Sleep(1500);
                TerminalDefault.terminal();
            }
            catch 
            {

                RootObject.information("Информация", "Неверный формат!");
                Thread.Sleep(1500);
                ReachConsoleSet.reachconsoleset();
            }

        }
    }
}
