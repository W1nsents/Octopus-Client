﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Client_Octopus.ClientBase.Modules.Modules;
using Memory;

namespace Octopus_Client.Memory.CraftSDK
{
    public class Pointers
    {

        Mem m = new Mem();
        public static Pointers instance;
        public static UInt64 mousePitch()
        {
            UInt64[] offs = { 0x30, 0xE0, 0x28, 0x30, 0x168, 0x0, 0x14 };
            return MCM.baseEvaluatePointer(0x03020990, offs);
        }
        public static UInt64 mouseYaw()
        {
            UInt64[] offs = { 0x30, 0xE0, 0x28, 0x30, 0x168, 0x0, 0x10 };
            return MCM.baseEvaluatePointer(0x03020990, offs);
        }
        public static UInt64 playerSpeed()
        {
            UInt64[] offs = { 0x30, 0x18, 0x0, 0x10B8, 0x18, 0x178, 0xB4 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 distf5()
        {
            UInt64[] offs = { 0x30, 0x2C8, 0x0, 0xD8, 0x20, 0xC10 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }
        public static UInt64 defflyspeed()
        {
            UInt64[] offs = { 0x30, 0x18, 0x0, 0x1298, 0x358, 0x34 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 hbw1()
        {
            UInt64[] offs = { 0x30, 0x2C8, 0x0, 0x18, 0x8, 0x198 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 enemyflag()
        {
            UInt64[] offs = { 0x30, 0x2C8, 0x0, 0x18, 0x8, 0x198 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
            //Minecraft.Windows.exe+01921888,10,60,13C8,10,3C8
        }



        public static UInt64 hbw2()
        {
            UInt64[] offs = { 0x30, 0xD8, 0x10, 0x10, 0x28, 0xE8, 0x198 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }


        public static UInt64 weather()
        {
            UInt64[] offs = { 0x30, 0x18, 0x18, 0xD8, 0x38, 0x10, 0x30 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 handma()
        {
            UInt64[] offs = { 0x28, 0x110 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }


        public static UInt64 fightbyte()
        {
            UInt64[] offs = { 0x30, 0x30, 0x0, 0x58, 0x3C8 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }


        public static UInt64 reachcall()
        {
            UInt64[] offs = { 0x30, 0x18, 0x0, 0x10B8, 0x18, 0x178, 0xB4  };
            return MCM.baseEvaluatePointer(0x11F5718, offs);
        }

        public static UInt64 stepsizee()
        {
            UInt64[] offs = { 0x18, 0x38, 0x0, 0x58, 0x1AC };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 xvel()
        {
            UInt64[] offs = { 0x18, 0x60, 0xAC };
            return MCM.baseEvaluatePointer(0x01291DF8, offs);
        }


        public static UInt64 zvel()
        {
            UInt64[] offs = { 0x18, 0x60, 0xB4 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 yvel()
        {
            UInt64[] offs = { 0x18, 0x60, 0xB0 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 Y1()
        {
            UInt64[] offs = { 0x30, 0x328, 0x0, 0x68, 0x90, 0x18, 0x164 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 Y2()
        {
            UInt64[] offs = { 0x30, 0x328, 0x0, 0x68, 0x90, 0x18, 0x164 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 time()
        {
            UInt64[] offs = { 0x10, 0x58, 0x58, 0xD8, 0x0, 0x38, 0x194 };
            return MCM.baseEvaluatePointer(0x01921888, offs);
        }

        public static UInt64 mousepitch()
        {
            UInt64[] offs = { 0x18, 0x58, 0xB8 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public List<float> directionalVector(float yaw, float pitch)
        {
            List<float> calculations = new List<float>();
            calculations.Add((float)Math.Cos(yaw) * (float)Math.Cos(pitch));
            calculations.Add((float)Math.Sin(pitch));
            calculations.Add((float)Math.Sin(yaw) * (float)Math.Cos(pitch));
            return calculations;
        }

        public List<float> getCalculationsToPos(float[] localPos, float[] targetPos)
        {
            List<float> calculations = new List<float>();

            float dX = localPos[0] - targetPos[0];
            float dY = localPos[1] - targetPos[1];
            float dZ = localPos[2] - targetPos[2];
            double distance = Math.Sqrt(dX * dX + dY * dY + dZ * dZ);
            float pitch = ((float)Math.Atan2(dY, (float)distance) * (float)3.13810205 / (float)3.141592653589793);
            float yaw = ((float)Math.Atan2(dZ, dX) * (float)3.1381025 / (float)3.141592653589793) + (float)-1.569051027;
            calculations.Add(-pitch);
            calculations.Add(-yaw);
            return calculations;
        }

        public static UInt64 mouseyaw()
        {
            UInt64[] offs = { 0x30, 0xD8, 0x10, 0x10, 0x28, 0x58, 0xB8 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 fov()
        {
            UInt64[] offs = { 0x8, 0x10, 0x0, 0x0, 0x0, 0x0, 0x28, 0x98 };
            return MCM.baseEvaluatePointer(0x019209F0, offs);
        }



        public static UInt64 hitboxwinsent1()
        {
            UInt64[] offs = { 0x30, 0x18, 0x8, 0x198 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 hitboxwinsent2()
        {
            UInt64[] offs = { 0x30, 0x210, 0x18, 0x8, 0x10, 0xB8, 0x198 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }
        public static UInt64 breakbypass()
        {
            UInt64[] offs = { 0x30, 0x2D8, 0x0, 0x10, 0xC0, 0x10, 0x28 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }


        public static UInt64 hitboxwinsent3()
        {
            UInt64[] offs = { 0x30, 0xD8, 0x0, 0x38, 0x30, 0x8, 0x198 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 hitboxwinsent4()
        {
            UInt64[] offs = { 0x10, 0x40, 0xE8, 0x58, 0x18, 0x8, 0x198 };
            return MCM.baseEvaluatePointer(0x01920A30, offs);
        }

        public static UInt64 flySpeed()
        {
            UInt64[] offs = { 0x18, 0x60, 0x10F0 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static UInt64 OnGround()
        {
            UInt64[] offs = { 0x18, 0x58, 0xD8, 0x18, 0xB0, 0xE8, 0x130 };
            return MCM.baseEvaluatePointer(0x01921DF8, offs);
        }

        public static int blockPlaceFlag
        {
            get
            {
                UInt64[] offs = { 0xA8, 0x18, 0x130, 0x540, 0x0, 0x850 };
                return MCM.readInt(MCM.baseEvaluatePointer(0x02FF8E38, offs));
            }
            set
            {
                UInt64[] offs = { 0xA8, 0x18, 0x130, 0x540, 0x0, 0x850 };
                MCM.writeInt(MCM.baseEvaluatePointer(0x02FF8E38, offs), value);
            }
        }
        public static int blockSide
        {
            get
            {
                UInt64[] offs = { 0xA8, 0x18, 0x130, 0x540, 0x0, 0x854 };
                return MCM.readInt(MCM.baseEvaluatePointer(0x02FF8E38, offs));
            }
            set
            {
                UInt64[] offs = { 0xA8, 0x18, 0x130, 0x540, 0x0, 0x854 };
                MCM.writeInt(MCM.baseEvaluatePointer(0x02FF8E38, offs), value);
            }
        }
        public static int blockPosX
        {
            get
            {
                UInt64[] offs = { 0x18, 0x60, 0xD8, 0x18, 0x70, 0x128, 0x174 };
                return MCM.readInt(MCM.baseEvaluatePointer(0x01921DF8, offs));
            }
            set
            {
                UInt64[] offs = { 0x18, 0x60, 0xD8, 0x18, 0x70, 0x128, 0x174 };
                MCM.writeInt(MCM.baseEvaluatePointer(0x01921DF8, offs), value);
            }
        }
        public static int blockPosY
        {
            get
            {
                UInt64[] offs = { 0x30, 0x328, 0x0, 0x68, 0x90, 0x18, 0x164 };
                return MCM.readInt(MCM.baseEvaluatePointer(0x01921DF8, offs));
            }
            set
            {
                UInt64[] offs = { 0x30, 0x328, 0x0, 0x68, 0x90, 0x18, 0x164 };
                MCM.writeInt(MCM.baseEvaluatePointer(0x01921DF8, offs), value);
            }
        }
        public static int blockPosZ
        {
            get
            {
                UInt64[] offs = {  };
                return MCM.readInt(MCM.baseEvaluatePointer(0x1, offs));
            }
            set
            {
                UInt64[] offs = { 0xA8, 0x18, 0x130, 0x540, 0x0, 0x860 };
                MCM.writeInt(MCM.baseEvaluatePointer(0x1, offs), value);
            }

        }
        public static int attackSwing = 0x102B81E; //1.1.5
        public static int handSwingPacket = 0x8A8E59; //1.1.5
        public static int rapidPlace = 0x102B7A0; //1.1.5
        public static int autoSprint = 0x443DD4;
        public static int reacha = 0x443DD4;
        public static int criticalsPacket = 0xFD9266; //1.1.5
        public static int headpluss = 0x9C2092; 
        public static int blockFace = 0x5D3F82; //1.1.5
        public static int noPacket = 0xF9F7DD; //1.1.5
        public static int movementPacket = 0x8AB7E7; //1.1.5
        public static int invalidMovementPacket = 0xFD923B; //1.1.5
        public static int NoSlowSneak1 = 0x4443D1; 
        public static int NoSlowSneak2 = 0x4443C9; 
        public static int NoKnockBackX = 0x9C7322; 
        public static int NoKnockBackY = 0x9C732B; 
        public static int NoKnockBackZ = 0x9C7334; 
        public static int ladderUp = 0xA1D120; 
        public static int ladderDown = 0xA1D06C; 
        public static int inWaterTick = 0x9CE5E8; //1.1.5
        public static int notInWaterTick = 0x120BD40; 
        public static int blockBreak = 0xA5A6FF;
        public static int InstantEat = 0x4AAB50;
        public static int noclipfly1 = 0xA3F8F9; 
        public static int noclip2 = 0xC83978;
        public static int jmp = 0x3545E6;
        public static int jmp2 = 0x3545EC;
        public static int spider = 0xA1D115;
        public static int ncc = 0x5BAE9C;
        public static int nohrt = 0xA2044F;
        public static int nohrtnn = 0x5B6A05;
        public static int stepsize = 0x9BF932;
        public static int antiafk = 0xAECAB0;
    }
}
