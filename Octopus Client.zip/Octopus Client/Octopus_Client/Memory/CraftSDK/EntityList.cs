﻿using Client_Octopus.ClientBase.UI.VObjs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Octopus_Client.Memory.CraftSDK
{
    public class EntityList
    {
        public static List<string> targetable
        {
            get
            {
                List<string> returned = new List<string>();
                foreach (VStringShelf shelf in VTargetsWindow.instance.targetObjects)
                {
                    returned.Add(shelf.text);
                }
                return returned;
            }
        }
        public static List<Entity> getEntityList(bool filter)
        {
            List<Entity> entityList = new List<Entity>();

            UInt64 likelySize = MCM.readBaseInt64(0x01921DF8);

            for (UInt64 index = 0; index < likelySize; index++)
            {
                UInt64[] startOffs = { 0x18, 0x38, 0x0, 0x58, 0xD8, 0x68, 0x70, index * 0x0 };
                UInt64 indexedEntity = MCM.readInt64(MCM.baseEvaluatePointer(0x01921DF8, startOffs));
                if (indexedEntity == SDK.instance.player.addr)
                    break;

                Entity eObj = new Entity(indexedEntity);
                if (eObj.movedTick > 1)
                {
                    if (filter)
                    {
                        if (targetable.Contains(eObj.type))
                        {
                            entityList.Add(eObj);
                        }
                    }
                    else
                        entityList.Add(eObj);
                }

            }
            return entityList;
        }

        public static List<PlayerEntity> getPlayerList()
        {
            List<PlayerEntity> playerEntityList = new List<PlayerEntity>();
            List<Entity> entityList = getEntityList(false);
            foreach (Entity entity in entityList)
            {
                if (entity.addr == SDK.instance.player.addr) continue;
                if (entity.type == "player")
                {
                    playerEntityList.Add(new PlayerEntity(entity.addr));
                }
            }
            return playerEntityList;
        }
    }
}
