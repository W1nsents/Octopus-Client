﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Octopus_Client.Memory.CraftSDK
{
    public class LocalPlayer : PlayerEntity
    {
        public UInt64 addr;
        public LocalPlayer(UInt64 addr) : base(addr)
        {
            this.addr = addr;
        }

        public void teleport(float x, float y, float z)
        {
            currentX1 = x;
            currentY1 = y;
            currentZ1 = z;
            X1 = x;
            X2 = x + 0.6f;
            Y1 = y;
            Y2 = y + 1.8f;
            Z1 = z;
            Z2 = z + 0.6f;
        }

        public double velocityXZ // Minecraft Bedrock 1.1.5
        {
            get
            {
                return Math.Sqrt(velX * velX + velZ * velZ);
            }
        }

        public double velocityXYZ // Minecraft Bedrock 1.1.5
        {
            get
            {
                return Math.Sqrt(velX * velX + velY * velY + velZ * velZ);
            }
        }

        public int onGround // Minecraft Bedrock 1.1.5
        {
            get {
                UInt64[] offs = { 0x130 };
                return MCM.readInt(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x130 };
                MCM.writeInt(MCM.evaluatePointer(addr, offs), value);
            }
        }

        public int fightbytes // Minecraft Bedrock 1.1.5
        {
            get
            {
                UInt64[] offs = { 0x30, 0x30, 0x0, 0x58, 0x3C8 };
                return MCM.readInt(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x30, 0x30, 0x0, 0x58, 0x3C8 };
                MCM.writeInt(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public byte isFlying
        {
            get
            {
                UInt64[] offs = { 0xA90 };
                return MCM.readByte(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0xA90 };
                MCM.writeByte(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public byte isInAir
        {
            get
            {
                UInt64[] offs = { 0x18, 0x60, 0x10F0 };
                return MCM.readByte(MCM.evaluatePointer(0x01921DF8, offs));
            }
            set
            {
                UInt64[] offs = { 0x18, 0x60, 0x10F0 };
                MCM.writeFloat(MCM.evaluatePointer(0x01921DF8, offs), value);
            }
        }


        public int isInWater
        {
            get
            {
                UInt64[] offs = { 0x23D };
                return MCM.readInt(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x23D };
                MCM.writeInt(MCM.evaluatePointer(addr, offs), value);
            }
        }   

        public float X1 // Minecraft Bedrock 1.1.5
        {
            get
            {
                UInt64[] offs = { 0x160 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x160 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float Y1 // Minecraft Bedrock 1.1.5
        {
            get
            {
                UInt64[] offs = { 0x164 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x164 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float Z1// Minecraft Bedrock 1.1.5
        {
            get
            {
                UInt64[] offs = { 0x168 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x168 }; 
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float X2
        {
            get
            {
                UInt64[] offs = { 0x43C };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x43C };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float Y2
        {
            get
            {
                UInt64[] offs = { 0x440 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x440 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float Z2
        {
            get
            {
                UInt64[] offs = { 0x444 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x444 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float blockCollisionStep
        {
            get
            {
                UInt64[] offs = { 0x1A8 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x1A8 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float velX
        {
            get
            {
                UInt64[] offs = { 0xAC };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0xAC };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }


        public float velY
        {
            get
            {
                UInt64[] offs = { 0xB0 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {

                UInt64[] offs = { 0xB0 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }

        public float velZ
        {
            get
            {
                UInt64[] offs = { 0xB4 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0xB4 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float yaw
        {
            get
            {
                UInt64[] offs = { 0xB8 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0xB8 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float pitch
        {
            get
            {
                UInt64[] offs = { 0xBC };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0xBC };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float hitboxs
        {
            get
            {
                UInt64[] offs = { 0x198 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x198 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
    }
    
}
