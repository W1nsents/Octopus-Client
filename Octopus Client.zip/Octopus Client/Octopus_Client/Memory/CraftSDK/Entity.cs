﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Octopus_Client.Memory.CraftSDK
{
    public class Entity
    {
        public UInt64 addr;
        public Entity(UInt64 addr)
        {
            this.addr = addr;
        }

        public float hitboxWidth
        {
            get
            {
                UInt64[] offs = { 0x198 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x198 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float hitboxHeight
        {
            get
            {
                UInt64[] offs = { 0x19C };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x19C };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float currentX1
        {
            get
            {
                UInt64[] offs = { 0x18, 0x60, 0xD8, 0x18, 0x70, 0x128, 0x174 };
                return MCM.readFloat(MCM.evaluatePointer(0x01921DF8, offs));
            }
            set
            {
                UInt64[] offs = { 0x18, 0x60, 0xD8, 0x18, 0x70, 0x128, 0x174 };
                MCM.writeFloat(MCM.evaluatePointer(0x01921DF8, offs), value);
            }
        }
        public float currentY1
        {
            get
            {
                UInt64[] offs = { 0x30, 0x328, 0x0, 0x68, 0x90, 0x18, 0x164 };
                return MCM.readFloat(MCM.evaluatePointer(0x01921DF8, offs));
            }
            set
            {
                UInt64[] offs = { 0x30, 0x328, 0x0, 0x68, 0x90, 0x18, 0x164 };
                MCM.writeFloat(MCM.evaluatePointer(0x01921DF8, offs), value);
            }
        }
        public float currentZ1
        {
            get
            {
                UInt64[] offs = { 0x90 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x90 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float currentX2
        {
            get
            {
                UInt64[] offs = { 0x94 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x94 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float currentY2
        {
            get
            {
                UInt64[] offs = { 0x98 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x98 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float currentZ2
        {
            get
            {
                UInt64[] offs = { 0x9C };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0x9C };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float currentX3
        {
            get
            {
                UInt64[] offs = { 0xA0 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0xA0 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float currentY3
        {
            get
            {
                UInt64[] offs = { 0xA4 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0xA4 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public float currentZ3
        {
            get
            {
                UInt64[] offs = { 0xA8 };
                return MCM.readFloat(MCM.evaluatePointer(addr, offs));
            }
            set
            {
                UInt64[] offs = { 0xA8 };
                MCM.writeFloat(MCM.evaluatePointer(addr, offs), value);
            }
        }
        public int movedTick
        {
            get
            {
                UInt64[] movedTic = { 0x32C };
                return MCM.readInt(MCM.evaluatePointer(addr, movedTic));
            }
            set
            {
                UInt64[] movedTic = { 0x32C };
                MCM.writeInt(MCM.evaluatePointer(addr, movedTic), value);
            }
        }
        public string type
        {
            get
            {
                UInt64[] offs = { 0x388 };
                return MCM.readString(MCM.evaluatePointer(addr, offs), 16);
            }
        }

        public string username
        {
            get
            {
                UInt64[] offs = { 0x1258 };
                return MCM.readString(MCM.evaluatePointer(addr, offs), 20);
            }
        }

        public void teleportE(float x, float y, float z)
        {
            currentX1 = x + 0.6f;
            currentY1 = y + 1.8f;
            currentZ1 = z + 0.6f;
        }
        public double distanceTo(Entity e)
        {
            float dX = currentX1 - e.currentX1;
            float dY = currentY1 - e.currentY1;
            float dZ = currentZ1 - e.currentZ1;
            return Math.Sqrt(dX * dX + dY * dY + dZ * dZ);
        }
    }
}
