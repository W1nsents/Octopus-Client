﻿using Octopus_Client.ClientBase.Categories;
using Client_Octopus.ClientBase.IO;
using Client_Octopus.ClientBase.Keybinds;
using Client_Octopus.ClientBase.Modules;
using Octopus_Client.Memory;
using Octopus_Client.Memory.CraftSDK;
using Client_Octopus.UI;
using Client_Octopus.UI.TabUI;
using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;
using System.IO.Compression;
using System.IO;
using System.Media;

namespace Client_Octopus
{
    class OctopusInject   
    {

        public static string version =" Client [by Winsent]";
        public static int threadSleep = 1;
        public static EventHandler<EventArgs> mainLoop;
        static void Main(string[] args)
        {;
            Console.Title = "Терминал | Octopus Cient - Регистрация данных";
            Console.WriteLine("╔═╦═╦══╦═╦═╦╗╔╦══╗╔═╦╗╔╦═╦═╦╦══╗\n║║║╠╬╗╔╣║║╔╣╚╝╠╗╚╣║╠╣╚╣║╦╣║║╠╗╔╝\n╚═╩═╝╚╝╚═╩╝╚══╩══╝╚═╩═╩╩═╩╩═╝╚╝", Color.Violet);
            RootObject.information("Информация", "Запуск Minecraft: Windows 10 Edition");
            Process.Start("minecraft://");
            RootObject.information("Информация", "Запуск Minecraft: Windows 10 Edition выполнен!");
            try
            {
                MCM.openGame();     
                MCM.openWindowHost();

                SDK sdk = new SDK();
                FileMan fm = new FileMan();
                CategoryHandler ch = new CategoryHandler();
                TabUiHandler tuih = new TabUiHandler();
                ModuleHandler mh = new ModuleHandler();
                KeybindHandler kh = new KeybindHandler();
                Thread uiApp = new Thread(() => { OverlayHost ui = new OverlayHost(); Application.Run(ui); });
                if (fm.readConfig())
                {
                    RootObject.information("Информация", "Конфиг загружен!");

                }
                else
                {
                    RootObject.information("Информация", "Не удалось загрузить конфиг!");
                }

                uiApp.Start();
                while (true)
                {
                    try
                    {
                        mainLoop.Invoke(null, new EventArgs());
                        Thread.Sleep(threadSleep);
                    }
                    catch (Exception)
                    {

                    }
                }
            } catch (Exception)
            {
                MessageBox.Show("Octopus крашнулся!", "Octopus Crashed");
            }
        }
    }
}
